#include "rpn.h"

RpnCalc newRpnCalc(){
    // TODO initialize new RpnCalc
}

void push(RpnCalc* rpnCalc, double n){
    // TODO push n on stack, expand stack if neccesary
}

void performOp(RpnCalc* rpnCalc, char op){
    // TODO perform operation
}

double peek(RpnCalc* rpnCalc){
    // TODO return top element of stack
}
